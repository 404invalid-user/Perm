# rtl8192-linux-driver

[how to make it work](https://404invalid-user.gitbook.io/invalid-gitbook/guides/get-tp-link-tl-wn823n-to-work-on-raspberry-pi-os)